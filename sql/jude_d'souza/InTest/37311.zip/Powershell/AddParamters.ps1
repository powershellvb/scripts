<# The sample scripts are not supported under any Microsoft standard support 
 program or service. The sample scripts are provided AS IS without warranty  
 of any kind. Microsoft further disclaims all implied warranties including,  
 without limitation, any implied warranties of merchantability or of fitness for 
 a particular purpose. The entire risk arising out of the use or performance of  
 the sample scripts and documentation remains with you. In no event shall 
 Microsoft, its authors, or anyone else involved in the creation, production, or 
 delivery of the scripts be liable for any damages whatsoever (including, 
 without limitation, damages for loss of business profits, business interruption, 
 loss of business information, or other pecuniary loss) arising out of the use 
 of or inability to use the sample scripts or documentation, even if Microsoft 
 has been advised of the possibility of such damages 
#>

param(
    # The parameter you want to add
    [Parameter(Mandatory = $true)][String]$StartupParameters
)

# get all the instances on a server
$property = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"
$instancesObject = $property.psobject.properties | ?{$_.Value -like 'MSSQL*'} 
$instances = $instancesObject.Value

#get all the parameters you input
$parameters = $StartupParameters.split(",")

#add all the startup parameters
if($instances)
{
     foreach($instance in $instances)
     {
            $ins = $instance.split('.')[1]
            if($ins -eq "MSSQLSERVER")
            {
                $instanceName = $env:COMPUTERNAME
            }
            else
            {
                $instanceName = $env:COMPUTERNAME + "\" + $ins
            }
            $regKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instance\MSSQLServer\Parameters"
            $property = Get-ItemProperty $regKey
            #$property
            $paramObjects = $property.psobject.properties | ?{$_.Name -like 'SQLArg*'}
            $count = $paramObjects.count
            foreach($parameter in $parameters)
            {
                if($parameter -notin $paramObjects.value)
                {                
                Write-Host "Adding startup parameter:SQLArg$count for $instanceName"
                $newRegProp = "SQLArg"+$count
                Set-ItemProperty -Path $regKey -Name $newRegProp -Value $parameter
                $count = $count + 1
		Write-Host "Add sucessfully!"
                }
            }
     }
}